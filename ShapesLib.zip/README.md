# Content
1. ShapesLib.Lib -- a Library Project
2. ShapesLib.Test -- a xUnit Test Project
3. TestCoverage -- test coverage info

# Library Features
1. Creating Figures:
  - Circle;
  - Triangle;
  - Square;
2. Calculating Figure Area
3. Recognising Rectangled Triangle


# Used Tools
+ Visual Studio Code
+ .NET 7.0.111
+ lcov, genhtml
