﻿namespace ShapesLib.Lib;
public interface IShape
{
    double Area{get; }
}