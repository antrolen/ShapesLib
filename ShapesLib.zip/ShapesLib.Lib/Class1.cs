﻿namespace ShapesLib.Lib;
public class Class1
{

}
